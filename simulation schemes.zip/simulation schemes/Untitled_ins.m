clc;
clear;
close all;
T=0.01; k=1;N=1;NN=2000*2.5;S=NN*T;

x0(:,1)=[1.5 1.5 0.355]'; a_0=[0 0.1 0;0 0 -0.2;0 -0.01 0]; u1(:,1)=[0 0 0]';u2(:,1)=[0 0 0]';u3(:,1)=[0 0 0]'; alpha1(:,1)=[0 0 0]';alpha2(:,1)=[0 0 0]';alpha3(:,1)=[0 0 0]';
I=[1,1,1]'; II=[1 0 0;0 1 0;0 0 1]'; 
%a_0=[0 0.1 0;-0.1 0 0;0.01 0 0];
detal=2.5; c1=2.5; c2=5; c3=10; mu1=0.5;    a12=1; a13=1; a21=1;  a23=1; a31=1;a32=1;% the estimator 
beta11=1.6; beta12=20; beta21=1.8; beta22=15; beta31=1.7; beta32=30;
yita1(:,1)=[0 0 0]'; yita2(:,1)=[0 0 0]';  yita3(:,1)=[0 0 0]'; kesai1(:,1)=[0 0 0]';kesai2(:,1)=[0 0 0]';kesai3(:,1)=[0 0 0]';
cha1=31.55; Y1=[cos(cha1) -sin(cha1) 0;sin(cha1) cos(cha1) 0;0 0 1]; x11(:,1)=[0.1 0.5 0.1]'; x12(:,1)=[4 3 2]';
cha2=30.25; Y2=[cos(cha2) -sin(cha2) 0;sin(cha2) cos(cha2) 0;0 0 1]; x21(:,1)=[0 1 0.1]'; x22(:,1)=[4 3 2]';
cha3=31.15; Y3=[cos(cha3) -sin(cha3) 0;sin(cha3) cos(cha3) 0;0 0 1]; x31(:,1)=[-0.12 0.6 0.1]'; x32(:,1)=[4 3 2]';

Yc11=1.5;Yc12=2;Ya11=5;Ya12=1.7;Yc21=0.5;Yc22=2;Ya21=5; Ya22=1.7;
Yc31=0.8;Yc32=2;Ya31=5;Ya32=1.7; Y11=3.6; Y12=3.5;  Y21=3.6; Y22=3.5; Y31=3.6; Y32=3.5; 

U1=0;U2=0;U3=0;

tt1=0; uu1=0; m1=0.02; B(1,1)=0.5; E=0.5;be=4.5; Y=6;
tt2=0; uu2=0; m2=0.03; B(2,1)=0.5; E=0.5;be2=4.5; YY=6;
tt3=0; uu3=0; m3=0.04; B(3,1)=0.5; E=0.5;be3=4.5; YYY=6;
W11(:,k)=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]';
%W11(:,k)=[0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4]';
Wc11(:,k)=[0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2]'; 
Wa11(:,k)=[0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4]'; 
W12(:,k)=[0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8]';
Wc12(:,k)=[0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1]';
Wa12(:,k)=[0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3]'; 
Wc21(:,k)=[0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2]'; 
Wa21(:,k)=[0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4]'; 
W21(:,k)=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]';
Wc22(:,k)=[0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1]'; 
Wa22(:,k)=[0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3]'; 
W22(:,k)=[0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8]';
Wc31(:,k)=[0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2]'; 
Wa31(:,k)=[0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4]'; 
W31(:,k)=[0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4]';
Wc32(:,k)=[0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1]';  
Wa32(:,k)=[0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3]'; 
W32(:,k)=[0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8]';

N1=200;N2=400;N3=650;N4=700;N5=1200;N6=1280;N7=1700;N8=1840; AP=2.5*[0 N1 N2 N3 N4 N5 N6 N7 N8 2000];
for j=1:5
    
for   k=N+AP(1,2*j-1):N+AP(1,2*j)
 
s1(:,k)=[-0.05+0.02*cos(0.1*k*T) -0.05+0.02*cos(0.1*k*T) 0]'; ds1(:,k)=[-0.002*sin(0.1*k*T) -0.002*sin(0.1*k*T) 0]';
s2(:,k)=[0.09 0.09 0]'; ds2(:,k)=[0 0 0]';
s3(:,k)=[0.04+0.02*sin(0.1*k*T) 0.04+0.02*sin(0.1*k*T) 0]'; ds3(:,k)=[0.002*cos(0.1*k*T) 0.002*cos(0.1*k*T) 0]';
   
 %the estimator 1
yita1(:,k+1)=yita1(:,k)+T*(-detal*(yita1(:,k)-kesai1(:,k))+ds1(:,k)+a_0*(kesai1(:,k)-s1(:,k)));
kesai1(:,k+1)=kesai1(:,k)+T*(a_0*(kesai1(:,k)-s1(:,k))-c1*(a12*(kesai1(:,k)-s1(:,k)-kesai2(:,k)+s2(:,k))+a13*(kesai1(:,k)-s1(:,k)-kesai3(:,k)...
    +s3(:,k)))-c1*mu1*(kesai1(:,k)-s1(:,k)-x0(:,k))+ds1(:,k));
%the estimator 2
yita2(:,k+1)=yita2(:,k)+T*(-detal*(yita2(:,k)-kesai2(:,k))+ds2(:,k)+a_0*(kesai2(:,k)-s2(:,k)));
kesai2(:,k+1)=kesai2(:,k)+T*(a_0*(kesai2(:,k)-s2(:,k))-c2*(a21*(kesai2(:,k)-s2(:,k)-kesai1(:,k)+s1(:,k))+a23*(kesai2(:,k)-s2(:,k)-kesai3(:,k)...
    +s3(:,k)))+ds2(:,k));
%the estimator 3
yita3(:,k+1)=yita3(:,k)+T*(-detal*(yita3(:,k)-kesai3(:,k))+ds3(:,k)+a_0*(kesai3(:,k)-s3(:,k)));
kesai3(:,k+1)=kesai3(:,k)+T*(a_0*(kesai3(:,k)-s3(:,k))-c3*(a31*(kesai3(:,k)-s3(:,k)-kesai1(:,k)+s1(:,k))+a32*(kesai3(:,k)-s3(:,k)-kesai2(:,k)...
    +s2(:,k)))+ds3(:,k));



%the fomation error 1
z11(:,k)=(x11(:,k)-yita1(:,k));
z12(:,k)=(x12(:,k)-alpha1(:,k));

%the fomation error 2
z21(:,k)=(x21(:,k)-yita2(:,k));
z22(:,k)=(x22(:,k)-alpha2(:,k));

%the fomation error 2
z31(:,k)=(x31(:,k)-yita3(:,k));
z32(:,k)=(x32(:,k)-alpha3(:,k));
    
    

for i=1:18
   S_11(i,k)= exp(-((norm(z11(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_12(i,k)= exp(-((norm(z12(:,k))-6+i*12/12)^2/2));
end

for i=1:18
   S_21(i,k)= exp(-((norm(z21(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_22(i,k)= exp(-((norm(z22(:,k))-6+i*12/12)^2/2)); 
end

for i=1:18
   S_31(i,k)= exp(-((norm(z31(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_32(i,k)= exp(-((norm(z32(:,k))-6+i*12/12)^2/2)); 
end

%the leader
x0(:,k+1)=x0(:,k)+T*a_0*x0(:,k);
%the follower 1  
x11(:,k+1)=x11(:,k)+T*Y1*x12(:,k);
x12(:,k+1)=x12(:,k)+T*(-x12(:,k)+x11(:,k)+u1(:,k));
%the follower 2  
x21(:,k+1)=x21(:,k)+T*Y2*x22(:,k);
x22(:,k+1)=x22(:,k)+T*(-x22(:,k)+x21(:,k)+u2(:,k));
%the follower 3  
x31(:,k+1)=x31(:,k)+T*Y3*x32(:,k);
x32(:,k+1)=x32(:,k)+T*(-x32(:,k)+x31(:,k)+u3(:,k));


%the virtual controllors (agent 1 without DoS attacks)
alpha1(:,k+1)=-beta11*z11(:,k)-W11(:,k)'*S_11(:,k)*I-0.5*Wa11(:,k)'*S_11(:,k)*I+(detal*II+a_0)*kesai1(:,k)-detal*yita1(:,k)...
    +ds1(:,k)-a_0*s1(:,k);
u1(:,k+1)=-beta12*z12(:,k)-W12(:,k)'*S_12(:,k)*I-0.5*Wa12(:,k)'*S_12(:,k)*I;
%the virtual controllors (agent 2 without DoS attacks)
alpha2(:,k+1)=-beta21*z21(:,k)-W21(:,k)'*S_21(:,k)*I-0.5*Wa21(:,k)'*S_21(:,k)*I+(detal*II+a_0)*kesai2(:,k)-detal*yita2(:,k)...
    +ds2(:,k)-a_0*s2(:,k);
u2(:,k+1)=-beta22*z22(:,k)-W22(:,k)'*S_22(:,k)*I-0.5*Wa22(:,k)'*S_22(:,k)*I;
%the virtual controllors (agent 3 without DoS attacks)
alpha3(:,k+1)=-beta31*z31(:,k)-W31(:,k)'*S_31(:,k)*I-0.5*Wa31(:,k)'*S_31(:,k)*I+(detal*II+a_0)*kesai3(:,k)-detal*yita3(:,k)...
    +ds1(:,k)-a_0*s1(:,k);
u3(:,k+1)=-beta32*z32(:,k)-W32(:,k)'*S_32(:,k)*I-0.5*Wa32(:,k)'*S_32(:,k)*I;


%the update laws (agent 1) 

W11(:,k+1)=W11(:,k)+T*1.8*(S_11(:,k)*norm(z11(:,k))-Y11*W11(:,k));
W12(:,k+1)=W12(:,k)+T*1.4*(S_12(:,k)*norm(z12(:,k))-Y12*W12(:,k));
Wc11(:,k+1)=Wc11(:,k)+T*(-Yc11*S_11(:,k)*S_11(:,k)'*Wc11(:,k));
Wa11(:,k+1)=Wa11(:,k)+T*(-S_11(:,k)*S_11(:,k)'*(Ya11*(Wa11(:,k)-Wc11(:,k))+Yc11*Wc11(:,k)));
Wc12(:,k+1)=Wc12(:,k)+T*(-Yc12*S_12(:,k)*S_12(:,k)'*Wc12(:,k));
Wa12(:,k+1)=Wa12(:,k)+T*(-S_12(:,k)*S_12(:,k)'*(Ya12*(Wa12(:,k)-Wc12(:,k))+Yc12*Wc12(:,k)));
%the update laws (agent 2)
W21(:,k+1)=W21(:,k)+T*1.8*(S_21(:,k)*norm(z21(:,k))-Y21*W21(:,k));
W22(:,k+1)=W22(:,k)+T*1.4*(S_22(:,k)*norm(z22(:,k))-Y22*W22(:,k));
Wc21(:,k+1)=Wc21(:,k)+T*(-Yc21*S_21(:,k)*S_21(:,k)'*Wc21(:,k));
Wa21(:,k+1)=Wa21(:,k)+T*(-S_21(:,k)*S_21(:,k)'*(Ya21*(Wa21(:,k)-Wc21(:,k))+Yc21*Wc21(:,k)));
Wc22(:,k+1)=Wc22(:,k)+T*(-Yc22*S_22(:,k)*S_22(:,k)'*Wc22(:,k));
Wa22(:,k+1)=Wa22(:,k)+T*(-S_22(:,k)*S_22(:,k)'*(Ya22*(Wa22(:,k)-Wc22(:,k))+Yc22*Wc22(:,k)));
%the update laws (agent 3)
W31(:,k+1)=W31(:,k)+T*1.8*(S_31(:,k)*norm(z31(:,k))-Y31*W31(:,k));
W32(:,k+1)=W32(:,k)+T*1.4*(S_32(:,k)*norm(z32(:,k))-Y32*W32(:,k));
Wc31(:,k+1)=Wc31(:,k)+T*(-Yc31*S_31(:,k)*S_31(:,k)'*Wc31(:,k));
Wa31(:,k+1)=Wa31(:,k)+T*(-S_31(:,k)*S_31(:,k)'*(Ya31*(Wa31(:,k)-Wc31(:,k))+Yc31*Wc31(:,k)));
Wc32(:,k+1)=Wc32(:,k)+T*(-Yc32*S_32(:,k)*S_32(:,k)'*Wc32(:,k));
Wa32(:,k+1)=Wa32(:,k)+T*(-S_32(:,k)*S_32(:,k)'*(Ya32*(Wa32(:,k)-Wc32(:,k))+Yc32*Wc32(:,k)));

% trigger 1
xi(1,k)=exp(-Y*k*T);
alphap(1,k)=-(1+B(1,k))*(u1(1,k)*u1(1,k)*z12(1,k)/(u1(1,k)*u1(1,k)*z12(1,k)*z12(1,k)+xi(1,k)*xi(1,k))^0.5...
    +z12(1,k)*E/(E*E*z12(1,k)*z12(1,k)+xi(1,k)*xi(1,k))^0.5);
B(1,k+1)=B(1,k)+T*(-be*B(1,k)*B(1,k));
if abs(alphap(1,k)-U1)>B(1,k)*abs(U1)+m1
           U1=alphap(1,k);
           tt1=[tt1;k*T];
           uu1=[uu1 alphap(1,k)];  
   end
          u1(1,k)=uu1(end);   
 %%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt1=0; uuu1=0;Uu1=0;Uu2=0;Uu3=0;
if Uu1<=D
alphapp(1,k)=-(1+Bb)*(u1(2,k)*tanh(z12(2,k)*u1(2,k)/2)+h1*tanh(h1*z12(2,k)));
if abs(alphapp(1,k)-Uu1)>Bb*abs(Uu1)+mm1
           Uu1=alphapp(1,k);
           ttt1=[ttt1;k*T];
           uuu1=[uuu1 alphapp(1,k)];  
   end
         
else
alphapp(1,k)=z12(2,k)-h2*tanh(h2*z12(2,k));
if abs(alphapp(1,k)-Uu1)>mm2
           Uu1=alphapp(1,k);
           ttt1=[ttt1;k*T];
           uuu1=[uuu1 alphapp(1,k)];  
   end
             
end   
          
      
% trigger 2
xi(2,k)=exp(-YY*k*T);
alphap(2,k)=-(1+B(2,k))*(u2(1,k)*u2(1,k)*z22(1,k)/(u2(1,k)*u2(1,k)*z22(1,k)*z22(1,k)+xi(2,k)*xi(2,k))^0.5...
    +z22(1,k)*E/(E*E*z22(1,k)*z22(1,k)+xi(2,k)*xi(2,k))^0.5);
B(2,k+1)=B(2,k)+T*(-be2*B(2,k)*B(2,k));
if abs(alphap(2,k)-U2)>B(2,k)*abs(U2)+m2
           U2=alphap(2,k);
           tt2=[tt2;k*T];
           uu2=[uu2 alphap(2,k)];  
   end
          u2(1,k)=uu1(end);             

%%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt2=0; uuu2=0;Uu1=0;Uu2=0;Uu3=0;
if Uu2<=D
alphapp(2,k)=-(1+Bb)*(u2(2,k)*tanh(z22(2,k)*u2(2,k)/2)+h1*tanh(h1*z22(2,k)));
if abs(alphapp(2,k)-Uu2)>Bb*abs(Uu2)+mm1
           Uu2=alphapp(2,k);
           ttt2=[ttt2;k*T];
           uuu2=[uuu2 alphapp(2,k)];  
   end
         
else
alphapp(2,k)=z22(2,k)-h2*tanh(h2*z22(2,k));
if abs(alphapp(2,k)-Uu2)>mm2
           Uu2=alphapp(2,k);
           ttt2=[ttt2;k*T];
           uuu2=[uuu2 alphapp(2,k)];  
   end
             
end             
          
          
          
          
% trigger 3
xi(3,k)=exp(-YYY*k*T);
alphap(3,k)=-(1+B(3,k))*(u3(1,k)*u3(1,k)*z32(1,k)/(u3(1,k)*u3(1,k)*z32(1,k)*z32(1,k)+xi(3,k)*xi(3,k))^0.5...
    +z32(1,k)*E/(E*E*z32(1,k)*z32(1,k)+xi(3,k)*xi(3,k))^0.5);
B(3,k+1)=B(3,k)+T*(-be3*B(3,k)*B(3,k));
if abs(alphap(3,k)-U3)>B(3,k)*abs(U3)+m3
           U3=alphap(3,k);
           tt3=[tt3;k*T];
           uu3=[uu3 alphap(3,k)];  
   end
          u3(1,k)=uu3(end);  
          

%%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt3=0; uuu3=0;Uu1=0;Uu2=0;Uu3=0;
if Uu3<=D
alphapp(3,k)=-(1+Bb)*(u3(2,k)*tanh(z32(2,k)*u3(2,k)/2)+h1*tanh(h1*z32(2,k)));
if abs(alphapp(3,k)-Uu3)>Bb*abs(Uu3)+mm1
           Uu3=alphapp(3,k);
           ttt3=[ttt3;k*T];
           uuu3=[uuu3 alphapp(3,k)];  
   end
         
else
alphapp(3,k)=z32(2,k)-h2*tanh(h2*z32(2,k));
if abs(alphapp(3,k)-Uu3)>mm2
           Uu3=alphapp(3,k);
           ttt3=[ttt3;k*T];
           uuu3=[uuu3 alphapp(3,k)];  
   end
             
end   
             

WC1(1,k)=norm(Wc11(:,k));
WC1(2,k)=norm(Wc21(:,k));
WC1(3,k)=norm(Wc31(:,k));
WA1(1,k)=norm(Wa11(:,k));
WA1(2,k)=norm(Wa21(:,k));
WA1(3,k)=norm(Wa31(:,k));

WC2(1,k)=norm(Wc12(:,k));
WC2(2,k)=norm(Wc22(:,k));
WC2(3,k)=norm(Wc32(:,k));
WA2(1,k)=norm(Wa12(:,k));
WA2(2,k)=norm(Wa22(:,k));
WA2(3,k)=norm(Wa32(:,k));

W1(1,k)=norm(W11(:,k));
W1(2,k)=norm(W21(:,k));
W1(3,k)=norm(W31(:,k));
W2(1,k)=norm(W12(:,k));
W2(2,k)=norm(W22(:,k));
W2(3,k)=norm(W32(:,k));
z1(1,k)=norm(z11(:,k)); z1(2,k)=norm(z12(:,k)); 
z2(1,k)=norm(z21(:,k)); z2(2,k)=norm(z22(:,k)); 
z3(1,k)=norm(z31(:,k)); z3(2,k)=norm(z32(:,k)); 

Z(1,k)=norm(yita1(:,k)-s1(:,k)-x0(:,k));
Z(2,k)=norm(yita2(:,k)-s2(:,k)-x0(:,k));
Z(3,k)=norm(yita3(:,k)-s3(:,k)-x0(:,k)); 

ZZ(1,k)=norm(x11(:,k)-ds1(:,k)-x0(:,k));
ZZ(2,k)=norm(x21(:,k)-ds2(:,k)-x0(:,k));
ZZ(3,k)=norm(x31(:,k)-ds3(:,k)-x0(:,k));%fomation errors

Cost1(1,k)=z11(1,k)*z11(1,k)+alpha1(1,k)*alpha1(1,k);
Cost1(2,k)=z21(1,k)*z21(1,k)+alpha2(1,k)*alpha2(1,k);
Cost1(3,k)=z31(1,k)*z31(1,k)+alpha3(1,k)*alpha3(1,k);
Cost2(1,k)=z12(1,k)*z12(1,k)+u1(1,k)*u1(1,k);
Cost2(2,k)=z22(1,k)*z22(1,k)+u2(1,k)*u2(1,k);
Cost2(3,k)=z32(1,k)*z32(1,k)+u3(1,k)*u3(1,k);


end
if j<5
for  k=N+AP(1,2*j)+1:N+AP(1,2*j+1)-1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s1(:,k)=[-0.05+0.02*cos(0.1*k*T) -0.05+0.02*cos(0.1*k*T) 0]'; ds1(:,k)=[-0.002*sin(0.1*k*T) -0.002*sin(0.1*k*T) 0]';
s2(:,k)=[0.09 0.09 0]'; ds2(:,k)=[0 0 0]';
s3(:,k)=[0.04+0.02*sin(0.1*k*T) 0.04+0.02*sin(0.1*k*T) 0]'; ds3(:,k)=[0.002*cos(0.1*k*T) 0.002*cos(0.1*k*T) 0]';
    
%the estimator 1
yita1(:,k+1)=yita1(:,k)+T*(-detal*(yita1(:,k)-kesai1(:,k))+ds1(:,k)+a_0*(kesai1(:,k)-s1(:,k)));
kesai1(:,k+1)=kesai1(:,k)+T*(a_0*(kesai1(:,k)-s1(:,k)));
%the estimator 2
yita2(:,k+1)=yita2(:,k)+T*(-detal*(yita2(:,k)-kesai2(:,k))+ds2(:,k)+a_0*(kesai2(:,k)-s2(:,k)));
kesai2(:,k+1)=kesai2(:,k)+T*(a_0*(kesai2(:,k)-s2(:,k)));
%the estimator 3
yita3(:,k+1)=yita3(:,k)+T*(-detal*(yita3(:,k)-kesai3(:,k))+ds3(:,k)+a_0*(kesai3(:,k)-s3(:,k)));
kesai3(:,k+1)=kesai3(:,k)+T*(a_0*(kesai3(:,k)-s3(:,k)));

%the fomation error 1
z11(:,k)=(x11(:,k)-yita1(:,k));
z12(:,k)=(x12(:,k)-alpha1(:,k));

%the fomation error 2
z21(:,k)=(x21(:,k)-yita2(:,k));
z22(:,k)=(x22(:,k)-alpha2(:,k));

%the fomation error 2
z31(:,k)=(x31(:,k)-yita3(:,k));
z32(:,k)=(x32(:,k)-alpha3(:,k));    
    

for i=1:18
   S_11(i,k)= exp(-((norm(z11(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_12(i,k)= exp(-((norm(z12(:,k))-6+i*12/12)^2/2)); 
end

for i=1:18
   S_21(i,k)= exp(-((norm(z21(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_22(i,k)= exp(-((norm(z22(:,k))-6+i*12/12)^2/2)); 
end

for i=1:18
   S_31(i,k)= exp(-((norm(z31(:,k))-6+i*12/18)^2)); 
end
for i=1:12
   S_32(i,k)= exp(-((norm(z32(:,k))-6+i*12/12)^2/2)); 
end

%the leader
x0(:,k+1)=x0(:,k)+T*a_0*x0(:,k);
%the follower 1  
x11(:,k+1)=x11(:,k)+T*Y1*x12(:,k);
x12(:,k+1)=x12(:,k)+T*(-x12(:,k)+x11(:,k)+u1(:,k));
%the follower 2  
x21(:,k+1)=x21(:,k)+T*Y2*x22(:,k);
x22(:,k+1)=x22(:,k)+T*(-x22(:,k)+x21(:,k)+u2(:,k));
%the follower 3  
x31(:,k+1)=x31(:,k)+T*Y3*x32(:,k);
x32(:,k+1)=x32(:,k)+T*(-x32(:,k)+x31(:,k)+u3(:,k));



%the virtual controllors (agent 1 without DoS attacks)
alpha1(:,k+1)=-beta11*z11(:,k)-W11(:,k)'*S_11(:,k)*I-0.5*Wa11(:,k)'*S_11(:,k)*I+(detal*II+a_0)*kesai1(:,k)-detal*yita1(:,k)...
    +ds1(:,k)-a_0*s1(:,k);
u1(:,k+1)=-beta12*z12(:,k)-W12(:,k)'*S_12(:,k)*I-0.5*Wa12(:,k)'*S_12(:,k)*I;
%the virtual controllors (agent 2 without DoS attacks)
alpha2(:,k+1)=-beta21*z21(:,k)-W21(:,k)'*S_21(:,k)*I-0.5*Wa21(:,k)'*S_21(:,k)*I+(detal*II+a_0)*kesai2(:,k)-detal*yita2(:,k)...
    +ds2(:,k)-a_0*s2(:,k);
u2(:,k+1)=-beta22*z22(:,k)-W22(:,k)'*S_22(:,k)*I-0.5*Wa22(:,k)'*S_22(:,k)*I;
%the virtual controllors (agent 3 without DoS attacks)
alpha3(:,k+1)=-beta31*z31(:,k)-W31(:,k)'*S_31(:,k)*I-0.5*Wa31(:,k)'*S_31(:,k)*I+(detal*II+a_0)*kesai3(:,k)-detal*yita3(:,k)...
    +ds1(:,k)-a_0*s1(:,k);
u3(:,k+1)=-beta32*z32(:,k)-W32(:,k)'*S_32(:,k)*I-0.5*Wa32(:,k)'*S_32(:,k)*I;


%the update laws (agent 1) 

W11(:,k+1)=W11(:,k)+T*1.8*(S_11(:,k)*norm(z11(:,k))-Y11*W11(:,k));
W12(:,k+1)=W12(:,k)+T*1.4*(S_12(:,k)*norm(z12(:,k))-Y12*W12(:,k));
Wc11(:,k+1)=Wc11(:,k)+T*(-Yc11*S_11(:,k)*S_11(:,k)'*Wc11(:,k));
Wa11(:,k+1)=Wa11(:,k)+T*(-S_11(:,k)*S_11(:,k)'*(Ya11*(Wa11(:,k)-Wc11(:,k))+Yc11*Wc11(:,k)));
Wc12(:,k+1)=Wc12(:,k)+T*(-Yc12*S_12(:,k)*S_12(:,k)'*Wc12(:,k));
Wa12(:,k+1)=Wa12(:,k)+T*(-S_12(:,k)*S_12(:,k)'*(Ya12*(Wa12(:,k)-Wc12(:,k))+Yc12*Wc12(:,k)));
%the update laws (agent 2)
W21(:,k+1)=W21(:,k)+T*1.8*(S_21(:,k)*norm(z21(:,k))-Y21*W21(:,k));
W22(:,k+1)=W22(:,k)+T*1.4*(S_22(:,k)*norm(z22(:,k))-Y22*W22(:,k));
Wc21(:,k+1)=Wc21(:,k)+T*(-Yc21*S_21(:,k)*S_21(:,k)'*Wc21(:,k));
Wa21(:,k+1)=Wa21(:,k)+T*(-S_21(:,k)*S_21(:,k)'*(Ya21*(Wa21(:,k)-Wc21(:,k))+Yc21*Wc21(:,k)));
Wc22(:,k+1)=Wc22(:,k)+T*(-Yc22*S_22(:,k)*S_22(:,k)'*Wc22(:,k));
Wa22(:,k+1)=Wa22(:,k)+T*(-S_22(:,k)*S_22(:,k)'*(Ya22*(Wa22(:,k)-Wc22(:,k))+Yc22*Wc22(:,k)));
%the update laws (agent 3)
W31(:,k+1)=W31(:,k)+T*1.8*(S_31(:,k)*norm(z31(:,k))-Y31*W31(:,k));
W32(:,k+1)=W32(:,k)+T*1.4*(S_32(:,k)*norm(z32(:,k))-Y32*W32(:,k));
Wc31(:,k+1)=Wc31(:,k)+T*(-Yc31*S_31(:,k)*S_31(:,k)'*Wc31(:,k));
Wa31(:,k+1)=Wa31(:,k)+T*(-S_31(:,k)*S_31(:,k)'*(Ya31*(Wa31(:,k)-Wc31(:,k))+Yc31*Wc31(:,k)));
Wc32(:,k+1)=Wc32(:,k)+T*(-Yc32*S_32(:,k)*S_32(:,k)'*Wc32(:,k));
Wa32(:,k+1)=Wa32(:,k)+T*(-S_32(:,k)*S_32(:,k)'*(Ya32*(Wa32(:,k)-Wc32(:,k))+Yc32*Wc32(:,k)));    




% trigger 1
xi(1,k)=exp(-Y*k*T);
alphap(1,k)=-(1+B(1,k))*(u1(1,k)*u1(1,k)*z12(1,k)/(u1(1,k)*u1(1,k)*z12(1,k)*z12(1,k)+xi(1,k)*xi(1,k))^0.5...
    +z12(1,k)*E/(E*E*z12(1,k)*z12(1,k)+xi(1,k)*xi(1,k))^0.5);
B(1,k+1)=B(1,k)+T*(-be*B(1,k)*B(1,k));
if abs(alphap(1,k)-U1)>B(1,k)*abs(U1)+m1
           U1=alphap(1,k);
           tt1=[tt1;k*T];
           uu1=[uu1 alphap(1,k)];  
   end
          u1(1,k)=uu1(end);   
 %%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt1=0; uuu1=0;Uu1=0;Uu2=0;Uu3=0;
if Uu1<=D
alphapp(1,k)=-(1+Bb)*(u1(2,k)*tanh(z12(2,k)*u1(2,k)/2)+h1*tanh(h1*z12(2,k)));
if abs(alphapp(1,k)-Uu1)>Bb*abs(Uu1)+mm1
           Uu1=alphapp(1,k);
           ttt1=[ttt1;k*T];
           uuu1=[uuu1 alphapp(1,k)];  
   end
         
else
alphapp(1,k)=z12(2,k)-h2*tanh(h2*z12(2,k));
if abs(alphapp(1,k)-Uu1)>mm2
           Uu1=alphapp(1,k);
           ttt1=[ttt1;k*T];
           uuu1=[uuu1 alphapp(1,k)];  
   end
             
end   
          
      
% trigger 2
xi(2,k)=exp(-YY*k*T);
alphap(2,k)=-(1+B(2,k))*(u2(1,k)*u2(1,k)*z22(1,k)/(u2(1,k)*u2(1,k)*z22(1,k)*z22(1,k)+xi(2,k)*xi(2,k))^0.5...
    +z22(1,k)*E/(E*E*z22(1,k)*z22(1,k)+xi(2,k)*xi(2,k))^0.5);
B(2,k+1)=B(2,k)+T*(-be2*B(2,k)*B(2,k));
if abs(alphap(2,k)-U2)>B(2,k)*abs(U2)+m2
           U2=alphap(2,k);
           tt2=[tt2;k*T];
           uu2=[uu2 alphap(2,k)];  
   end
          u2(1,k)=uu1(end);             

%%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt2=0; uuu2=0;Uu1=0;Uu2=0;Uu3=0;
if Uu2<=D
alphapp(2,k)=-(1+Bb)*(u2(2,k)*tanh(z22(2,k)*u2(2,k)/2)+h1*tanh(h1*z22(2,k)));
if abs(alphapp(2,k)-Uu2)>Bb*abs(Uu2)+mm1
           Uu2=alphapp(2,k);
           ttt2=[ttt2;k*T];
           uuu2=[uuu2 alphapp(2,k)];  
   end
         
else
alphapp(2,k)=z22(2,k)-h2*tanh(h2*z22(2,k));
if abs(alphapp(2,k)-Uu2)>mm2
           Uu2=alphapp(2,k);
           ttt2=[ttt2;k*T];
           uuu2=[uuu2 alphapp(2,k)];  
   end
             
end             
          
          
          
          
% trigger 3
xi(3,k)=exp(-YYY*k*T);
alphap(3,k)=-(1+B(3,k))*(u3(1,k)*u3(1,k)*z32(1,k)/(u3(1,k)*u3(1,k)*z32(1,k)*z32(1,k)+xi(3,k)*xi(3,k))^0.5...
    +z32(1,k)*E/(E*E*z32(1,k)*z32(1,k)+xi(3,k)*xi(3,k))^0.5);
B(3,k+1)=B(3,k)+T*(-be3*B(3,k)*B(3,k));
if abs(alphap(3,k)-U3)>B(3,k)*abs(U3)+m3
           U3=alphap(3,k);
           tt3=[tt3;k*T];
           uu3=[uu3 alphap(3,k)];  
   end
          u3(1,k)=uu3(end);  
          

%%%%%%%%  
 D=4; Bb=0.02; h1=10;h2=10; mm1=0.2; mm2=0.15; ttt3=0; uuu3=0;Uu1=0;Uu2=0;Uu3=0;
if Uu3<=D
alphapp(3,k)=-(1+Bb)*(u3(2,k)*tanh(z32(2,k)*u3(2,k)/2)+h1*tanh(h1*z32(2,k)));
if abs(alphapp(3,k)-Uu3)>Bb*abs(Uu3)+mm1
           Uu3=alphapp(3,k);
           ttt3=[ttt3;k*T];
           uuu3=[uuu3 alphapp(3,k)];  
   end
         
else
alphapp(3,k)=z32(2,k)-h2*tanh(h2*z32(2,k));
if abs(alphapp(3,k)-Uu3)>mm2
           Uu3=alphapp(3,k);
           ttt3=[ttt3;k*T];
           uuu3=[uuu3 alphapp(3,k)];  
   end
             
end   



WC1(1,k)=norm(Wc11(:,k));
WC1(2,k)=norm(Wc21(:,k));
WC1(3,k)=norm(Wc31(:,k));
WA1(1,k)=norm(Wa11(:,k));
WA1(2,k)=norm(Wa21(:,k));
WA1(3,k)=norm(Wa31(:,k));

WC2(1,k)=norm(Wc12(:,k));
WC2(2,k)=norm(Wc22(:,k));
WC2(3,k)=norm(Wc32(:,k));
WA2(1,k)=norm(Wa12(:,k));
WA2(2,k)=norm(Wa22(:,k));
WA2(3,k)=norm(Wa32(:,k));

W1(1,k)=norm(W11(:,k));
W1(2,k)=norm(W21(:,k));
W1(3,k)=norm(W31(:,k));
W2(1,k)=norm(W12(:,k));
W2(2,k)=norm(W22(:,k));
W2(3,k)=norm(W32(:,k));

z1(1,k)=norm(z11(:,k)); z1(2,k)=norm(z12(:,k)); 
z2(1,k)=norm(z21(:,k)); z2(2,k)=norm(z22(:,k)); 
z3(1,k)=norm(z31(:,k)); z3(2,k)=norm(z32(:,k)); 
Z(1,k)=norm(yita1(:,k)-s1(:,k)-x0(:,k));
Z(2,k)=norm(yita2(:,k)-s2(:,k)-x0(:,k));
Z(3,k)=norm(yita3(:,k)-s3(:,k)-x0(:,k)); 

ZZ(1,k)=norm(x11(:,k)-ds1(:,k)-x0(:,k));
ZZ(2,k)=norm(x21(:,k)-ds2(:,k)-x0(:,k));
ZZ(3,k)=norm(x31(:,k)-ds3(:,k)-x0(:,k));%fomation errors

Cost1(1,k)=z11(1,k)*z11(1,k)+alpha1(1,k)*alpha1(1,k);
Cost1(2,k)=z21(1,k)*z21(1,k)+alpha2(1,k)*alpha2(1,k);
Cost1(3,k)=z31(1,k)*z31(1,k)+alpha3(1,k)*alpha3(1,k);
Cost2(1,k)=z12(1,k)*z12(1,k)+u1(1,k)*u1(1,k);
Cost2(2,k)=z22(1,k)*z22(1,k)+u2(1,k)*u2(1,k);
Cost2(3,k)=z32(1,k)*z32(1,k)+u3(1,k)*u3(1,k);

    end
end
end



figure (1) %the fomation errors
 for k=1:4
  MM=10;
fq(:,k)=fill([(AP(:,2*k)+1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k)+1)*T],[-2 -2 MM MM],'k');
set(fq(:,k),'FaceColor',[0.7,0.7,0.7],'FaceAlpha',1,'LineStyle','none');
hold on
 end 
tout=0:T:S;
h1=plot(tout,ZZ(1,1:NN+1),'r-','linewidth',2);
h2=plot(tout,ZZ(2,1:NN+1),'b-','linewidth',2);
h3=plot(tout,ZZ(3,1:NN+1),'g-','linewidth',2);
str11='$\left\| {{{\bar e}_1}} \right\|$ when ${\tau _f} = 4$';
str12='$\left\| {{{\bar e}_2}} \right\|$ when ${\tau _f} = 4$';
str13='$\left\| {{{\bar e}_3}} \right\|$ when ${\tau _f} = 4$';
xlabel('Times[sec]')
legend([h1,h2,h3,fq(:,4)],{str11,str12,str13,'DoS'},'Interpreter','latex');
hold on

figure (2) %the estimation errors
 for k=1:4
  MM=3;
fq(:,k)=fill([(AP(:,2*k)+1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k)+1)*T],[-1 -1 MM MM],'k');
set(fq(:,k),'FaceColor',[0.7,0.7,0.7],'FaceAlpha',1,'LineStyle','none');
hold on
 end 
tout=0:T:S;
h1=plot(tout,Z(1,1:NN+1),'r-','linewidth',2);
h2=plot(tout,Z(2,1:NN+1),'b-','linewidth',2);
h3=plot(tout,Z(3,1:NN+1),'g--','linewidth',2);
str11='$\left\| {{e_1}} \right\|$ when ${\tau _f} = 4$';
str12='$\left\| {{e_2}} \right\|$ when ${\tau _f} = 4$';
str13='$\left\| {{e_3}} \right\|$ when ${\tau _f} = 4$';
xlabel('Times[sec]')
legend([h1,h2,h3,fq(:,4)],{str11,str12,str13,'DoS'},'Interpreter','latex');
hold on


figure(3) %the fomation errors of 3D
tout=0:T:S;
h1=plot3(x0(3,1:NN+1),x0(1,1:NN+1),tout,'r-','linewidth',2); hold on
h2=plot3(x11(3,1:NN+1),x11(1,1:NN+1),tout,'m--','linewidth',2); hold on
h3=plot3(x21(3,1:NN+1),x21(1,1:NN+1),tout,'g-','linewidth',2);hold on
h4=plot3(x31(3,1:NN+1),x31(1,1:NN+1),tout,'b-','linewidth',2);
str11='$\chi_L(t)$';
str12='$\chi_1(t)$ when ${\tau _f} = 4$';
str13='$\chi_2(t)$ when ${\tau _f} = 4$';
str14='$\chi_3(t)$ when ${\tau _f} = 4$';
xlabel('Times[sec]')
legend([h1,h2,h3,h4],{str11,str12,str13,str14},'Interpreter','latex');
hold on
figure (4) %%��ֵ����Cost1
 for k=1:4
  MM=8;
fq(:,k)=fill([(AP(:,2*k)+1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k)+1)*T],[0 0 MM MM],'k');
set(fq(:,k),'FaceColor',[0.7,0.7,0.7],'FaceAlpha',1,'LineStyle','none');
hold on
 end 
tout=0:T:S;
h1=plot(tout,Cost1(1,1:NN+1),'r-','linewidth',2);%,
h2=plot(tout,Cost1(2,1:NN+1),'y-','linewidth',2);
h3=plot(tout,Cost1(3,1:NN+1),'b-','linewidth',2);
str11='${c_{1,1}}$ when ${\tau _f} = 4$'; 
str12='${c_{2,1}}$ when ${\tau _f} = 4$';
str13='${c_{3,1}}$ when ${\tau _f} = 4$';
xlabel('Times[sec]')
legend([h1,h2,h3],{str11,str12,str13},'Interpreter','latex');
 hold on
figure (5) %%��ֵ����Cost2
 for k=1:4
  MM=35000;
fq(:,k)=fill([(AP(:,2*k)+1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k+1)-1)*T (AP(:,2*k)+1)*T],[0 0 MM MM],'k');
set(fq(:,k),'FaceColor',[0.7,0.7,0.7],'FaceAlpha',1,'LineStyle','none');
hold on
 end 
tout=0:T:S;
h1=plot(tout,Cost2(1,1:NN+1),'r-','linewidth',2);%,
h2=plot(tout,Cost2(2,1:NN+1),'y-','linewidth',2);
h3=plot(tout,Cost2(3,1:NN+1),'b-','linewidth',2);
str11='${c_{1,2}}$ when ${\tau _f} = 4$'; 
str12='${c_{2,2}}$ when ${\tau _f} = 4$';
str13='${c_{3,2}}$ when ${\tau _f} = 4$';
xlabel('Times[sec]')
legend([h1,h2,h3],{str11,str12,str13},'Interpreter','latex');
 hold on

 
 %  trigger  1
 s=tt1(2:length(tt1))-tt1(1:length(tt1)-1);
s=[0;s];
average=0;
disp('�ܵ�trigger����Ϊ��')
length(tt1)
disp('ƽ����������Ϊ��')
average=sum(s)/length(tt1)

figure (8)
stem(tt1(1:length(tt1)),s(1:length(tt1)),'linewidth',1);
 xlabel(' Times[sec]')
ylabel('The release instants and release interval');   
legend('The trigger instant of MSV 1 ({\tau _f} = 4)'); 
%   2
s=tt2(2:length(tt2))-tt2(1:length(tt2)-1);
s=[0;s];
average=0;
disp('�ܵ�trigger����Ϊ��')
length(tt2)
disp('ƽ����������Ϊ��')
average=sum(s)/length(tt2)


figure (9)
stem(tt2(1:length(tt2)),s(1:length(tt2)),'linewidth',1);
 xlabel(' Times[sec]')
ylabel('The release instants and release interval');   
legend('The trigger instant of MSV 2 ({\tau _f} = 4)'); 

%     3
s=tt3(2:length(tt3))-tt3(1:length(tt3)-1);
s=[0;s];
average=0;
disp('�ܵ�trigger����Ϊ��')
length(tt3)
disp('ƽ����������Ϊ��')
average=sum(s)/length(tt3)

figure (10)
stem(tt3(1:length(tt3)),s(1:length(tt3)),'linewidth',1);
 xlabel(' Times[sec]')
ylabel('The release instants and release interval');   
legend('The trigger instant of MSV 3 ({\tau _f} = 4)'); 